def trigger_stage_chunk(event, context=None):
    return 'OK'