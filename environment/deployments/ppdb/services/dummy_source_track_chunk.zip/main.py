def track_chunk(event, context=None):
    return 'OK'